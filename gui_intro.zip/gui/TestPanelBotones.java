package gui;
import javax.swing.*;
public class TestPanelBotones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VentanaPanelRojoBlanco v=new VentanaPanelRojoBlanco();
		v.setVisible(true);

	}

}
