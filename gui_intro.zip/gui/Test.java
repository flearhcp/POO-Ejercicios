package gui;

public class Test {
	public static void main(String[] s) {
		Ventana inst = new Ventana();
		inst.setVisible(true);
	}
}
